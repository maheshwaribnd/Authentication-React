import { useState, useEffect } from 'react';
import { Button, Form } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import '../style.css/Profile.css'

const Profile = () => {

    let getName = window.localStorage.getItem("userName");
    let getEmail = window.localStorage.getItem("userEmail");
    let getPassword = window.localStorage.getItem("userPassword");

    // let getData = localStorage.getItem("userData");

    const navigate = useNavigate();

    // const [data, setData] = useState(JSON.parse(getData));
    // console.log("test")
    // console.log(getData)
    // const user_data = JSON.parse(getData);

    useEffect(() => {

        if (!getName.random) {
            setTimeout(() => {
                navigate('/signup');
            }, 400)
        }
    }, [])

    const Logout = () => {
        window.localStorage.setItem("userData", "");

        navigate('/')
    }

    return (
        <div id="profilepage">
            <h1>User Profile</h1>
            <Form.Group className="mb-3 profiletext" controlId="formBasicEmail">
                <Form.Label>Name : { getName } </Form.Label>
            </Form.Group>

            <Form.Group className="mb-3 profiletext" controlId="formBasicPassword">
                <Form.Label>Email : { getEmail } </Form.Label>
            </Form.Group>

            <Form.Group className="mb-3 profiletext" controlId="formBasicEmail">
                <Form.Label>Password : { getPassword } </Form.Label>
            </Form.Group>

            <Button onClick={Logout} variant="dark" type='button'>Logout</Button>
        </div>
    );
}

export default Profile;